jQuery(document).ready(function($){
$(".show-more a").each(function() {
    var $link = $(this);
    var $content = $link.parent().prev("div.text-content");

    console.log($link);

    var visibleHeight = $content[0].clientHeight;
    var actualHide = $content[0].scrollHeight - 1;

    console.log(actualHide);
    console.log(visibleHeight);

    if (actualHide > visibleHeight) {
        $link.show();
    } else {
        $link.hide();
    }
});

$(".show-more a").on("click", function() {
    var $link = $(this);
    var $content = $link.parent().prev("div.text-content");
    var linkText = $link.text();

    $content.toggleClass("short-text, full-text");

    $link.text(getShowLinkText(linkText));

    return false;
});

function getShowLinkText(currentText) {
    var newText = '';

    if (currentText.toUpperCase() === "SHOW MORE") {
        newText = "Show less";
    } else {
        newText = "Show more";
    }

    return newText;
}
});

jQuery(document).ready(function($){
	$('.flexslider').flexslider({
		animation: "slide",
		controlNav: false,
		directionNav: false,
        prevText: "", //String: Set the text for the "previous" directionNav item
        nextText: "", //String: Set the text for the "next" directionNav item
        animationLoop: true,
        slideshowSpeed: 5000, 
        slideshow: true,
        sync: "#slider"
    });

});
$(document).ready(function() {
  $('.-accordion').asAccordion({
    namespace: '-accordion',
    // accordion theme. WIP
    skin: null,

    // breakpoint for mobile devices. WIP
    mobile_breakpoint: 480,

    // initial index panel
    initialIndex: 0,

    // CSS3 easing effects.
    easing: 'ease-in-out',

    // animation speed.
    speed: 500,

    // vertical or horizontal
    direction: 'vertical',

    // jQuery mouse events. click, mousehover, etc.
    event: 'click'
  });
});

